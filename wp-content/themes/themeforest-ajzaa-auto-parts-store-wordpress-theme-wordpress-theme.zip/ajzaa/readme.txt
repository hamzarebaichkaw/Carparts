  Theme Name: Ajzaa
  Theme URI: http://themes.webdevia.com/ajzaa/
  Description: Awesome Business WordPress theme
  Author: Mymoun
  Author URI: http://www.webdevia.com/
  Version: 2.9